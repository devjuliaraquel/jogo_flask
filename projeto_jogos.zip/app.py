from flask import Flask, render_template

app = Flask(__name__)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/hanoi")
def hanoi():
    return render_template("hanoi.html")

@app.route("/adivinha")
def adivinha():
    return render_template("adivinha.html")

@app.route("/ppt")
def ppt():
    return render_template("ppt.html")

@app.route("/quiz")
def quiz():
    return render_template("quiz.html")

@app.route("/forca")
def forca():
    return render_template("forca.html")

if __name__ == "__main__":
    app.run(debug=True)
